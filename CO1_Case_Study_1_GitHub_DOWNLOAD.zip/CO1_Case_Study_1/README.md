# CO-1 Case Study 1 — Money and Pricing in an E-Commerce Catalog

This repository contains the case-study report and a runnable Java implementation.

## Files

- `CO1_Case_Study_1_Report.pdf` — report covering problem analysis, invariants, domain classification, UML class diagram, Java implementation, design justification, and team presentation.
- `Main.java` — complete Java source code. All classes are in this one file so it is easy to compile and run.

## Requirements

- Java JDK installed (Java 8+ should work; Java 17+ recommended).
- VS Code is optional. The program can also run from Terminal.

## Run in VS Code or Terminal

Open the folder containing `Main.java`, then run:

```bash
javac Main.java
java Main
```

The program demonstrates:
- Money stored as integer minor units.
- EUR, USD, JPY and KWD currency precision.
- Addition only when currencies match.
- Discount calculation using HALF_EVEN rounding.
- Positive quantity validation.
- Product and cart construction.
- Rejection of negative prices, invalid discounts, zero quantity, excess precision and mixed-currency addition.

## Important design notes

- `Money` represents non-negative monetary amounts.
- `Percentage` stores basis points from 0 to 10,000.
- `Quantity` must be at least 1.
- `Product` is identified by SKU.
- `Cart` is identified by cart ID and aggregates cart lines.
- Refunds should be modelled separately (for example, with `SignedMoney` or an `Adjustment` type), rather than allowing product prices to become negative.

## Before submission

Add your team name, member names, roll numbers, course/faculty details and any institution-required cover-page information to the report if required.


## Team — Group 5

| Roll Number | Name |
|---|---|
| 2520030339 | M. Tanmayee |
| 2520030277 | K. Sharanya |
| 2520030557 | B. Jasmitha |

The updated report also includes the five case-study exam questions with brief explanations for the team presentation.
