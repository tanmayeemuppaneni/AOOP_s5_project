import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/*
 * CO-1 Case Study 1: Money and Pricing in an E-Commerce Catalog
 *
 * Run:
 *   javac Main.java
 *   java Main
 *
 * Java 17 or later recommended. No external libraries are required.
 */

enum Currency {
    EUR(2),
    USD(2),
    JPY(0),
    KWD(3);

    private final int minorUnits;

    Currency(int minorUnits) {
        this.minorUnits = minorUnits;
    }

    public int getMinorUnits() {
        return minorUnits;
    }
}

final class Money {
    private final long minor;
    private final Currency currency;

    private Money(long minor, Currency currency) {
        if (minor < 0) {
            throw new IllegalArgumentException("Money cannot be negative.");
        }
        this.currency = Objects.requireNonNull(currency, "Currency cannot be null.");
        this.minor = minor;
    }

    // Creates Money from a decimal string, rejecting negative values
    // and values with more decimal places than the currency allows.
    public static Money of(String decimal, Currency currency) {
        Objects.requireNonNull(decimal, "Amount cannot be null.");
        Objects.requireNonNull(currency, "Currency cannot be null.");

        BigDecimal amount;
        try {
            amount = new BigDecimal(decimal);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Invalid money amount: " + decimal, ex);
        }

        if (amount.signum() < 0) {
            throw new IllegalArgumentException("Money cannot be negative.");
        }

        try {
            BigDecimal scaled = amount.setScale(
                    currency.getMinorUnits(),
                    RoundingMode.UNNECESSARY
            );
            long minorUnits = scaled
                    .movePointRight(currency.getMinorUnits())
                    .longValueExact();

            return new Money(minorUnits, currency);
        } catch (ArithmeticException ex) {
            throw new IllegalArgumentException(
                    "Amount has too many decimal places or is too large for " + currency,
                    ex
            );
        }
    }

    public long getMinor() {
        return minor;
    }

    public Currency getCurrency() {
        return currency;
    }

    private void requireSameCurrency(Money other) {
        Objects.requireNonNull(other, "Money cannot be null.");
        if (currency != other.currency) {
            throw new IllegalArgumentException(
                    "Currency mismatch: cannot combine " + currency + " and " + other.currency
            );
        }
    }

    public Money plus(Money other) {
        requireSameCurrency(other);
        return new Money(Math.addExact(minor, other.minor), currency);
    }

    public Money times(Quantity quantity) {
        Objects.requireNonNull(quantity, "Quantity cannot be null.");
        return new Money(Math.multiplyExact(minor, quantity.getValue()), currency);
    }

    // Returns the price after applying the percentage discount.
    public Money minus(Percentage discount) {
        Objects.requireNonNull(discount, "Discount cannot be null.");
        Money discountAmount = discount.applyTo(this);

        if (discountAmount.minor > minor) {
            throw new IllegalArgumentException("Discount cannot make the price negative.");
        }

        return new Money(minor - discountAmount.minor, currency);
    }

    public String toDecimalString() {
        BigDecimal amount = BigDecimal.valueOf(minor, currency.getMinorUnits());
        return amount.setScale(currency.getMinorUnits()).toPlainString();
    }

    @Override
    public String toString() {
        return toDecimalString() + " " + currency;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Money)) return false;

        Money other = (Money) obj;
        return minor == other.minor && currency == other.currency;
    }

    @Override
    public int hashCode() {
        return Objects.hash(minor, currency);
    }
}

final class Percentage {
    // 100 basis points = 1%; 10,000 basis points = 100%.
    private final int basisPoints;

    private Percentage(int basisPoints) {
        this.basisPoints = basisPoints;
    }

    public static Percentage ofBasisPoints(int basisPoints) {
        if (basisPoints < 0 || basisPoints > 10_000) {
            throw new IllegalArgumentException(
                    "Percentage must be between 0% and 100%."
            );
        }
        return new Percentage(basisPoints);
    }

    // Example: ofPercent("12.50") represents 12.50%.
    public static Percentage ofPercent(String percent) {
        Objects.requireNonNull(percent, "Percentage cannot be null.");

        try {
            BigDecimal value = new BigDecimal(percent);
            if (value.signum() < 0 || value.compareTo(new BigDecimal("100")) > 0) {
                throw new IllegalArgumentException(
                        "Percentage must be between 0% and 100%."
                );
            }

            int basisPoints = value
                    .movePointRight(2)
                    .intValueExact();

            return ofBasisPoints(basisPoints);
        } catch (NumberFormatException | ArithmeticException ex) {
            throw new IllegalArgumentException(
                    "Invalid percentage. Use at most two decimal places, for example 12.50.",
                    ex
            );
        }
    }

    public int getBasisPoints() {
        return basisPoints;
    }

    // Calculates the discount amount, rounded to the currency's minor unit
    // using HALF_EVEN rounding.
    public Money applyTo(Money money) {
        Objects.requireNonNull(money, "Money cannot be null.");

        BigDecimal discountMinor = BigDecimal.valueOf(money.getMinor())
                .multiply(BigDecimal.valueOf(basisPoints))
                .divide(BigDecimal.valueOf(10_000), 0, RoundingMode.HALF_EVEN);

        return Money.of(
                discountMinor.movePointLeft(money.getCurrency().getMinorUnits()).toPlainString(),
                money.getCurrency()
        );
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Percentage)) return false;

        Percentage other = (Percentage) obj;
        return basisPoints == other.basisPoints;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(basisPoints);
    }

    @Override
    public String toString() {
        return BigDecimal.valueOf(basisPoints, 2).toPlainString() + "%";
    }
}

final class Quantity {
    private final int value;

    private Quantity(int value) {
        this.value = value;
    }

    public static Quantity of(int value) {
        if (value < 1) {
            throw new IllegalArgumentException("Quantity must be at least 1.");
        }
        return new Quantity(value);
    }

    public int getValue() {
        return value;
    }

    public Quantity plus(Quantity other) {
        Objects.requireNonNull(other, "Quantity cannot be null.");
        return Quantity.of(Math.addExact(value, other.value));
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Quantity)) return false;

        Quantity other = (Quantity) obj;
        return value == other.value;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(value);
    }

    @Override
    public String toString() {
        return Integer.toString(value);
    }
}

// Product is an Entity: its SKU is its identity.
final class Product {
    private final String sku;
    private String name;
    private Money price;

    public Product(String sku, String name, Money price) {
        if (sku == null || sku.isBlank()) {
            throw new IllegalArgumentException("SKU cannot be empty.");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Product name cannot be empty.");
        }
        this.sku = sku;
        this.name = name;
        this.price = Objects.requireNonNull(price, "Price cannot be null.");
    }

    public String getSku() {
        return sku;
    }

    public String getName() {
        return name;
    }

    public Money getPrice() {
        return price;
    }

    public void updateName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Product name cannot be empty.");
        }
        this.name = name;
    }

    public void updatePrice(Money price) {
        this.price = Objects.requireNonNull(price, "Price cannot be null.");
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Product)) return false;

        Product other = (Product) obj;
        return sku.equals(other.sku);
    }

    @Override
    public int hashCode() {
        return sku.hashCode();
    }
}

// A cart line stores a product and a positive quantity.
// Lines are merged by product SKU inside the Cart.
final class CartLine {
    private final Product product;
    private Quantity quantity;

    public CartLine(Product product, Quantity quantity) {
        this.product = Objects.requireNonNull(product, "Product cannot be null.");
        this.quantity = Objects.requireNonNull(quantity, "Quantity cannot be null.");
    }

    public Product getProduct() {
        return product;
    }

    public Quantity getQuantity() {
        return quantity;
    }

    public void addQuantity(Quantity extra) {
        quantity = quantity.plus(extra);
    }

    public Money getLineTotal() {
        return product.getPrice().times(quantity);
    }
}

// Cart is an Entity / Aggregate Root: its cart ID identifies it.
final class Cart {
    private final String cartId;
    private final Map<String, CartLine> lines = new HashMap<>();

    public Cart(String cartId) {
        if (cartId == null || cartId.isBlank()) {
            throw new IllegalArgumentException("Cart ID cannot be empty.");
        }
        this.cartId = cartId;
    }

    public String getCartId() {
        return cartId;
    }

    public void addProduct(Product product, Quantity quantity) {
        Objects.requireNonNull(product, "Product cannot be null.");
        Objects.requireNonNull(quantity, "Quantity cannot be null.");

        CartLine existing = lines.get(product.getSku());
        if (existing == null) {
            lines.put(product.getSku(), new CartLine(product, quantity));
        } else {
            existing.addQuantity(quantity);
        }
    }

    public List<CartLine> getLines() {
        return Collections.unmodifiableList(new ArrayList<>(lines.values()));
    }

    public Money getTotal() {
        Money total = null;

        for (CartLine line : lines.values()) {
            Money lineTotal = line.getLineTotal();

            if (total == null) {
                total = lineTotal;
            } else {
                total = total.plus(lineTotal);
            }
        }

        if (total == null) {
            throw new IllegalStateException("An empty cart has no currency-defined total.");
        }

        return total;
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("===== E-COMMERCE MONEY AND PRICING CASE STUDY =====");

        // 1. Create money values.
        Money laptopPrice = Money.of("1000.00", Currency.USD);
        Money mousePrice = Money.of("25.50", Currency.USD);

        System.out.println("\n1. Money values:");
        System.out.println("Laptop price: " + laptopPrice);
        System.out.println("Mouse price: " + mousePrice);

        // 2. Add money in the same currency.
        Money combined = laptopPrice.plus(mousePrice);
        System.out.println("\n2. Addition:");
        System.out.println("Laptop + mouse = " + combined);

        // 3. Apply a percentage discount.
        Percentage discount = Percentage.ofPercent("15");
        Money discountAmount = discount.applyTo(laptopPrice);
        Money discountedPrice = laptopPrice.minus(discount);

        System.out.println("\n3. Discount:");
        System.out.println("Discount percentage: " + discount);
        System.out.println("Discount amount: " + discountAmount);
        System.out.println("Price after discount: " + discountedPrice);

        // 4. Multiply money by a positive quantity.
        Quantity quantity = Quantity.of(3);
        Money threeMice = mousePrice.times(quantity);

        System.out.println("\n4. Quantity:");
        System.out.println("Mouse quantity: " + quantity);
        System.out.println("Total for 3 mice: " + threeMice);

        // 5. Build a cart.
        Product laptop = new Product("LAP-101", "Laptop", laptopPrice);
        Product mouse = new Product("MOU-201", "Wireless Mouse", mousePrice);

        Cart cart = new Cart("CART-001");
        cart.addProduct(laptop, Quantity.of(1));
        cart.addProduct(mouse, Quantity.of(2));

        System.out.println("\n5. Shopping cart:");
        for (CartLine line : cart.getLines()) {
            System.out.println(
                    line.getProduct().getName()
                    + " x " + line.getQuantity()
                    + " = " + line.getLineTotal()
            );
        }
        System.out.println("Cart total: " + cart.getTotal());

        // 6. Demonstrate that different currencies cannot be added.
        System.out.println("\n6. Currency mismatch test:");
        try {
            Money euro = Money.of("100.00", Currency.EUR);
            laptopPrice.plus(euro);
        } catch (IllegalArgumentException ex) {
            System.out.println("Correctly rejected: " + ex.getMessage());
        }

        // 7. Demonstrate invalid values being rejected.
        System.out.println("\n7. Invalid value tests:");

        try {
            Money.of("-50.00", Currency.USD);
        } catch (IllegalArgumentException ex) {
            System.out.println("Negative price rejected: " + ex.getMessage());
        }

        try {
            Percentage.ofPercent("250");
        } catch (IllegalArgumentException ex) {
            System.out.println("250% discount rejected: " + ex.getMessage());
        }

        try {
            Quantity.of(0);
        } catch (IllegalArgumentException ex) {
            System.out.println("Zero quantity rejected: " + ex.getMessage());
        }

        try {
            Money.of("10.999", Currency.USD);
        } catch (IllegalArgumentException ex) {
            System.out.println("Excess precision rejected: " + ex.getMessage());
        }

        // 8. Demonstrate currency-specific precision.
        System.out.println("\n8. Currency precision:");
        System.out.println("JPY amount: " + Money.of("500", Currency.JPY));
        System.out.println("KWD amount: " + Money.of("12.345", Currency.KWD));

        // 9. Demonstrate Percentage equality and hashCode.
        Percentage p1 = Percentage.ofPercent("10");
        Percentage p2 = Percentage.ofBasisPoints(1000);

        System.out.println("\n9. Percentage equality:");
        System.out.println("p1 equals p2: " + p1.equals(p2));
        System.out.println("p1 hashCode equals p2 hashCode: "
                + (p1.hashCode() == p2.hashCode()));

        System.out.println("\n===== PROGRAM FINISHED SUCCESSFULLY =====");
    }
}
